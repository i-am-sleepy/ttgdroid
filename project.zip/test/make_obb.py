import struct, sys, os, random
# builds an NCTT/4ATT archive exactly like TTG Tools' packer
random.seed(1)
files=[("ui/frame_cinematic.d3dtx",b"\x01\x02"*5000),("scripts/main.lua",b"print('hi')\n"*50),("big/data.ttarch2",os.urandom(300000)),("x/y/z.prop",b"ERTM"+b"\0"*100)]
# add enough names to exercise name blocks
names=[n for n,_ in files]
nameblob=b""; offs=[]
for n in names:
    offs.append(len(nameblob)); nameblob+=n.encode()+b"\0"
nameSize=(len(nameblob)+0xFFFF)//0x10000*0x10000
nameblob=nameblob.ljust(nameSize,b"\0")
info=b""; fo=0
for (n,d),no in zip(files,offs):
    info+=struct.pack("<QQiiHH",random.getrandbits(64),fo,len(d),0,no//0x10000,no%0x10000); fo+=len(d)
data=b"".join(d for _,d in files)
common=len(data)+len(info)+nameSize+12
blob=b"NCTT"+struct.pack("<Q",common)+b"4ATT"+struct.pack("<II",nameSize,len(files))+info+nameblob+data
open(sys.argv[1],"wb").write(blob)
for n,d in files: open(os.path.join(sys.argv[2],os.path.basename(n)+".orig"),"wb").write(d)
