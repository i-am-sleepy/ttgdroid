import com.example.obbtool.ObbArchive;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
public class ObbTest {
  static void check(boolean c,String m){ if(!c){ System.out.println("FAIL: "+m); System.exit(1);} System.out.println("ok: "+m); }
  public static void main(String[] a) throws Exception {
    String path=a[0];
    RandomAccessFile raf=new RandomAccessFile(path,"rw");
    FileChannel ch=raf.getChannel();
    ObbArchive ar=ObbArchive.open(ch,ch);
    ar.readMagics();
    System.out.print(ar.listing());
    check(ar.count==4,"count 4");
    check(ar.entries.get(0).name.equals("ui/frame_cinematic.d3dtx"),"name 0");
    check(ar.entries.get(3).magic.equals("ERTM"),"magic");
    // extract
    ByteArrayOutputStream bo=new ByteArrayOutputStream();
    ar.extract(ar.entries.get(1),bo,null);
    check(java.util.Arrays.equals(bo.toByteArray(),Files.readAllBytes(Paths.get(a[1],"main.lua.orig"))),"extract equals original");
    // shrink replace in place
    long len0=ch.size();
    byte[] small=new byte[777]; java.util.Arrays.fill(small,(byte)7);
    String r1=ar.replace(ar.entries.get(0),new ByteArrayInputStream(small),small.length,null);
    check(r1.contains("in place") && ch.size()==len0,"in place keeps length");
    // grow replace -> append
    byte[] big=new byte[400000]; new java.util.Random(5).nextBytes(big);
    String r2=ar.replace(ar.entries.get(1),new ByteArrayInputStream(big),big.length,null);
    check(r2.contains("appended") && ch.size()==len0+big.length,"append grows file");
    ch.close(); raf.close();
    // reopen and verify
    raf=new RandomAccessFile(path,"r"); ch=raf.getChannel();
    ObbArchive b=ObbArchive.open(ch,null);
    check(b.entries.get(0).size==777,"size 0 persisted");
    check(b.entries.get(1).size==400000,"size 1 persisted");
    bo=new ByteArrayOutputStream(); b.extract(b.entries.get(1),bo,null);
    check(java.util.Arrays.equals(bo.toByteArray(),big),"appended data readable");
    bo=new ByteArrayOutputStream(); b.extract(b.entries.get(0),bo,null);
    check(java.util.Arrays.equals(bo.toByteArray(),small),"in-place data readable");
    bo=new ByteArrayOutputStream(); b.extract(b.entries.get(2),bo,null);
    check(java.util.Arrays.equals(bo.toByteArray(),Files.readAllBytes(Paths.get(a[1],"data.ttarch2.orig"))),"untouched entry intact");
    // archSize field
    java.nio.ByteBuffer bb=java.nio.ByteBuffer.allocate(8).order(java.nio.ByteOrder.LITTLE_ENDIAN); ch.read(bb,4);
    check(bb.getLong(0)==ch.size()-12,"archive size header = length-12");
    System.out.println("ALL OK");
  }
}
