package com.example.obbtool;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

/**
 * Reader/editor for uncompressed Telltale archives ("NCTT" + "3ATT"/"4ATT"), as used by Telltale .obb files.
 *
 * Layout (little endian):
 *   "NCTT" | u64 archiveSize (= fileLength - 12) | "4ATT" | [u32 2 only for "3ATT"] | u32 nameTableSize | u32 fileCount
 *   fileCount * 28 byte entries: u64 nameCrc64 | u64 offset | u32 size | u32 unknown | u16 nameBlock | u16 nameOff
 *   name table (nameTableSize bytes, zero terminated names, name pos = nameBlock*0x10000 + nameOff)
 *   file data; entry.offset is relative to the end of the name table.
 */
public final class ObbArchive {

    public interface Progress { void onProgress(long done, long total); }

    public static final class Entry {
        public int index;
        public long crc;
        public long offset;     // relative to dataStart
        public long size;
        public int unknown;
        public int nameBlock;
        public int nameOff;
        public String name;
        public String magic = "";   // first 4 bytes, printable only
        public long tablePos;       // absolute position of this entry's table record
        public long absPos;         // absolute position of data
        public boolean outOfRange;
    }

    private final FileChannel in;
    private final FileChannel out; // may be null (read only)

    public long fileLength;
    public boolean v3;
    public long nameTableSize;
    public int count;
    public long infoPos;
    public long dataStart;
    public String subMagic;
    public final List<Entry> entries = new ArrayList<Entry>();

    private ObbArchive(FileChannel in, FileChannel out) {
        this.in = in;
        this.out = out;
    }

    public boolean canWrite() { return out != null; }

    private static long u32(ByteBuffer b, int pos) { return b.getInt(pos) & 0xFFFFFFFFL; }
    private static int u16(ByteBuffer b, int pos) { return b.getShort(pos) & 0xFFFF; }

    private static void readFully(FileChannel ch, ByteBuffer buf, long pos) throws IOException {
        long p = pos;
        while (buf.hasRemaining()) {
            int n = ch.read(buf, p);
            if (n < 0) throw new IOException("Unexpected end of file at " + p);
            p += n;
        }
    }

    public static ObbArchive open(FileChannel in, FileChannel out) throws IOException {
        ObbArchive a = new ObbArchive(in, out);
        a.parse();
        return a;
    }

    private void parse() throws IOException {
        fileLength = in.size();
        if (fileLength < 32) throw new IOException("File is too small to be a Telltale archive");
        ByteBuffer head = ByteBuffer.allocate(32).order(ByteOrder.LITTLE_ENDIAN);
        readFully(in, head, 0);
        String magic = ascii(head, 0, 4);
        if (!"NCTT".equals(magic)) {
            if ("ECTT".equals(magic) || "ZCTT".equals(magic) || "eCTT".equals(magic) || "zCTT".equals(magic)) {
                throw new IOException("This archive is compressed/encrypted (" + magic + "). Only uncompressed NCTT archives (normal .obb files) are supported.");
            }
            throw new IOException("Not a Telltale archive (header \"" + magic + "\")");
        }
        subMagic = ascii(head, 12, 4);
        int p;
        if ("3ATT".equals(subMagic)) { v3 = true; p = 20; }
        else if ("4ATT".equals(subMagic)) { v3 = false; p = 16; }
        else throw new IOException("Unknown archive version \"" + subMagic + "\"");
        nameTableSize = u32(head, p);
        long cnt = u32(head, p + 4);
        if (cnt <= 0 || cnt > 5000000L) throw new IOException("Bad file count: " + cnt);
        count = (int) cnt;
        infoPos = p + 8;
        long namesPos = infoPos + 28L * count;
        dataStart = namesPos + nameTableSize;
        if (dataStart > fileLength) throw new IOException("Header is larger than the file");

        ByteBuffer info = ByteBuffer.allocate(28 * count).order(ByteOrder.LITTLE_ENDIAN);
        readFully(in, info, infoPos);
        ByteBuffer names = ByteBuffer.allocate((int) nameTableSize).order(ByteOrder.LITTLE_ENDIAN);
        readFully(in, names, namesPos);
        byte[] nb = names.array();

        entries.clear();
        for (int i = 0; i < count; i++) {
            int o = i * 28;
            Entry e = new Entry();
            e.index = i;
            e.crc = info.getLong(o);
            e.offset = info.getLong(o + 8);
            e.size = u32(info, o + 16);
            e.unknown = info.getInt(o + 20);
            e.nameBlock = u16(info, o + 24);
            e.nameOff = u16(info, o + 26);
            e.tablePos = infoPos + 28L * i;
            e.absPos = dataStart + e.offset;
            e.outOfRange = e.offset < 0 || e.absPos + e.size > fileLength;
            int np = e.nameBlock * 0x10000 + e.nameOff;
            StringBuilder sb = new StringBuilder();
            while (np >= 0 && np < nb.length && nb[np] != 0) { sb.append((char) (nb[np] & 0xFF)); np++; }
            e.name = sb.length() > 0 ? sb.toString() : ("<unnamed " + i + ">");
            entries.add(e);
        }
    }

    /** Reads the first 4 bytes of every entry (printable chars only). Cheap, run it in the background. */
    public void readMagics() throws IOException {
        ByteBuffer b = ByteBuffer.allocate(4);
        for (Entry e : entries) {
            if (e.outOfRange || e.size < 4) continue;
            b.clear();
            readFully(in, b, e.absPos);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 4; i++) {
                int c = b.get(i) & 0xFF;
                sb.append(c >= 32 && c < 127 ? (char) c : '.');
            }
            e.magic = sb.toString();
        }
    }

    public void extract(Entry e, OutputStream os, Progress pr) throws IOException {
        if (e.outOfRange) throw new IOException("Entry points outside of the file");
        ByteBuffer buf = ByteBuffer.allocate(1 << 20);
        long done = 0;
        while (done < e.size) {
            buf.clear();
            if (e.size - done < buf.capacity()) buf.limit((int) (e.size - done));
            readFully(in, buf, e.absPos + done);
            os.write(buf.array(), 0, buf.limit());
            done += buf.limit();
            if (pr != null) pr.onProgress(done, e.size);
        }
        os.flush();
    }

    /**
     * Replaces the data of an entry. If the new data fits it is written in place, otherwise it is appended at the
     * end of the archive. Returns a short description of what was done.
     */
    public String replace(Entry e, InputStream src, long srcSize, Progress pr) throws IOException {
        if (out == null) throw new IOException("Archive was opened read-only");
        if (srcSize < 0 || srcSize > 0x7FFFFFFFL) throw new IOException("Replacement must be smaller than 2 GB");
        boolean inPlace = srcSize <= e.size && !e.outOfRange;
        long writePos = inPlace ? e.absPos : fileLength;
        byte[] chunk = new byte[1 << 20];
        long done = 0;
        while (done < srcSize) {
            int want = (int) Math.min(chunk.length, srcSize - done);
            int n = src.read(chunk, 0, want);
            if (n < 0) throw new IOException("Replacement file ended early");
            ByteBuffer wb = ByteBuffer.wrap(chunk, 0, n);
            long p = writePos + done;
            while (wb.hasRemaining()) p += out.write(wb, p);
            done += n;
            if (pr != null) pr.onProgress(done, srcSize);
        }
        out.force(false);
        long newOffset = inPlace ? e.offset : (writePos - dataStart);

        // update table record (offset + size), then archive size if the file grew
        ByteBuffer rec = ByteBuffer.allocate(12).order(ByteOrder.LITTLE_ENDIAN);
        rec.putLong(newOffset).putInt((int) srcSize);
        rec.flip();
        long p = e.tablePos + 8;
        while (rec.hasRemaining()) p += out.write(rec, p);
        if (!inPlace) {
            long newLen = writePos + srcSize;
            ByteBuffer sz = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
            sz.putLong(newLen - 12);
            sz.flip();
            long q = 4;
            while (sz.hasRemaining()) q += out.write(sz, q);
            fileLength = newLen;
        }
        out.force(false);
        e.offset = newOffset;
        e.size = srcSize;
        e.absPos = dataStart + newOffset;
        e.outOfRange = false;
        return inPlace ? "written in place (archive size unchanged)" : "appended at end of archive (old data left as unused space)";
    }

    public String listing() {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append("NCTT/").append(subMagic).append("  files=").append(count)
          .append("  length=").append(fileLength).append("\n");
        sb.append("# index\tsize\toffset\tmagic\tname\n");
        for (Entry e : entries) {
            sb.append(e.index).append('\t').append(e.size).append('\t').append(e.absPos).append('\t')
              .append(e.magic).append('\t').append(e.name).append(e.outOfRange ? "\t[OUT OF RANGE]" : "").append('\n');
        }
        return sb.toString();
    }

    private static String ascii(ByteBuffer b, int pos, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            int c = b.get(pos + i) & 0xFF;
            sb.append(c >= 32 && c < 127 ? (char) c : '?');
        }
        return sb.toString();
    }
}
