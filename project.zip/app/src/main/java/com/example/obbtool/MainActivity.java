package com.example.obbtool;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_OPEN = 1, REQ_EXTRACT = 2, REQ_REPLACE = 3, REQ_LIST = 4;

    private ParcelFileDescriptor pfd;
    private FileChannel inCh, outCh;
    private ObbArchive archive;
    private String archiveName = "";

    private TextView info, status;
    private ProgressBar bar;
    private EditText filter;
    private ListView list;
    private ArrayAdapter<String> adapter;
    private final List<ObbArchive.Entry> shown = new ArrayList<ObbArchive.Entry>();
    private ObbArchive.Entry selected;
    private volatile boolean busy;

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(28), dp(10), dp(10));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button open = new Button(this);
        open.setText("Open OBB / archive");
        open.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { pickArchive(); }
        });
        Button export = new Button(this);
        export.setText("Export list");
        export.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { exportList(); }
        });
        row.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(export, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        info = new TextView(this);
        info.setText("Open an uncompressed Telltale archive (.obb). Copy the OBB out of Android/obb first (e.g. to Download) if the picker cannot see it.");
        info.setPadding(0, dp(6), 0, dp(6));
        root.addView(info);

        filter = new EditText(this);
        filter.setHint("Filter file names (e.g. ui, .d3dtx, frame)");
        filter.setSingleLine(true);
        filter.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int c, int d) {}
            public void afterTextChanged(Editable s) { applyFilter(); }
        });
        root.addView(filter);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        root.addView(bar);
        status = new TextView(this);
        root.addView(status);

        list = new ListView(this);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) showActions(shown.get(pos));
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeArchive();
    }

    // ---------------------------------------------------------------- open

    private void pickArchive() {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_OPEN);
    }

    private void closeArchive() {
        try { if (inCh != null) inCh.close(); } catch (Exception e) {}
        try { if (outCh != null) outCh.close(); } catch (Exception e) {}
        try { if (pfd != null) pfd.close(); } catch (Exception e) {}
        inCh = null; outCh = null; pfd = null; archive = null;
    }

    private void openArchive(final Uri uri) {
        busy = true;
        setStatus("Opening...", -1);
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                boolean writable = false;
                try {
                    closeArchive();
                    try {
                        pfd = getContentResolver().openFileDescriptor(uri, "rw");
                        writable = true;
                    } catch (Exception e) {
                        pfd = getContentResolver().openFileDescriptor(uri, "r");
                    }
                    inCh = new FileInputStream(pfd.getFileDescriptor()).getChannel();
                    if (writable) outCh = new FileOutputStream(pfd.getFileDescriptor()).getChannel();
                    archive = ObbArchive.open(inCh, outCh);
                    archive.readMagics();
                    archiveName = queryName(uri);
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage() != null ? t.getMessage() : t.toString());
                    closeArchive();
                }
                final String fe = err;
                final boolean fw = writable;
                runOnUiThread(new Runnable() {
                    public void run() {
                        busy = false;
                        if (fe != null) {
                            setStatus("", -1);
                            info.setText("Could not open: " + fe);
                            adapter.clear(); shown.clear();
                            adapter.notifyDataSetChanged();
                        } else {
                            refreshInfo(fw);
                            applyFilter();
                            setStatus("Opened " + archive.count + " files", -1);
                        }
                    }
                });
            }
        }).start();
    }

    private void refreshInfo(boolean writable) {
        if (archive == null) return;
        info.setText(archiveName + "\n" + archive.count + " files, " + fmtSize(archive.fileLength)
                + ", format " + archive.subMagic + (writable ? ", editable" : ", READ-ONLY (provider refused write access)"));
    }

    private String queryName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return "archive";
    }

    // ---------------------------------------------------------------- list

    private void applyFilter() {
        shown.clear();
        adapter.clear();
        if (archive != null) {
            String f = filter.getText().toString().trim().toLowerCase(Locale.ROOT);
            for (ObbArchive.Entry e : archive.entries) {
                if (f.length() == 0 || e.name.toLowerCase(Locale.ROOT).contains(f)) {
                    shown.add(e);
                    adapter.add(e.name + "\n" + fmtSize(e.size) + "  [" + e.magic + "]" + (e.outOfRange ? "  OUT OF RANGE" : ""));
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    private static String fmtSize(long s) {
        if (s >= 1L << 30) return String.format(Locale.ROOT, "%.2f GB", s / (double) (1L << 30));
        if (s >= 1L << 20) return String.format(Locale.ROOT, "%.2f MB", s / (double) (1L << 20));
        if (s >= 1L << 10) return String.format(Locale.ROOT, "%.1f KB", s / 1024.0);
        return s + " B";
    }

    private void showActions(ObbArchive.Entry e) {
        if (busy) return;
        selected = e;
        String[] items = new String[]{"Extract to file...", "Replace with file...", "Details"};
        new AlertDialog.Builder(this).setTitle(e.name).setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                if (which == 0) startExtract();
                else if (which == 1) startReplace();
                else showDetails();
            }
        }).show();
    }

    private void showDetails() {
        ObbArchive.Entry e = selected;
        if (e == null) return;
        new AlertDialog.Builder(this).setTitle("Details").setMessage(
                "Name: " + e.name + "\nSize: " + e.size + " bytes (" + fmtSize(e.size) + ")"
                        + "\nOffset in file: " + e.absPos + "\nFirst bytes: " + e.magic
                        + "\nIndex: " + e.index).setPositiveButton("OK", null).show();
    }

    // ---------------------------------------------------------------- extract

    private void startExtract() {
        String n = selected.name;
        int s = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
        if (s >= 0) n = n.substring(s + 1);
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, n);
        startActivityForResult(i, REQ_EXTRACT);
    }

    private void doExtract(final Uri dest) {
        final ObbArchive.Entry e = selected;
        final ObbArchive a = archive;
        if (e == null || a == null) return;
        busy = true;
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                try {
                    OutputStream os = getContentResolver().openOutputStream(dest, "wt");
                    try {
                        a.extract(e, os, progressCb("Extracting"));
                    } finally {
                        os.close();
                    }
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage() != null ? t.getMessage() : t.toString());
                }
                taskDone(err, "Extracted " + e.name);
            }
        }).start();
    }

    // ---------------------------------------------------------------- replace

    private void startReplace() {
        if (archive == null || !archive.canWrite()) {
            Toast.makeText(this, "Archive is read-only (the file picker did not give write access).", Toast.LENGTH_LONG).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_REPLACE);
    }

    private void confirmReplace(final Uri src) {
        final ObbArchive.Entry e = selected;
        if (e == null) return;
        long sz = -1;
        try {
            ParcelFileDescriptor p = getContentResolver().openFileDescriptor(src, "r");
            sz = p.getStatSize();
            p.close();
        } catch (Exception ex) {
            Toast.makeText(this, "Cannot read that file: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        final long newSize = sz;
        String how = newSize <= e.size
                ? "It fits, so it will be written in place."
                : "It is bigger, so it will be appended to the end of the OBB (the file grows by " + fmtSize(newSize) + ").";
        new AlertDialog.Builder(this).setTitle("Replace " + e.name + "?")
                .setMessage("Old size: " + fmtSize(e.size) + "\nNew size: " + fmtSize(newSize) + "\n\n" + how
                        + "\n\nThis edits the OBB directly. Keep a backup copy of the original OBB.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Replace", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { doReplace(src, newSize); }
                }).show();
    }

    private void doReplace(final Uri src, final long size) {
        final ObbArchive.Entry e = selected;
        final ObbArchive a = archive;
        busy = true;
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                String res = "";
                try {
                    InputStream is = getContentResolver().openInputStream(src);
                    try {
                        res = a.replace(e, is, size, progressCb("Writing"));
                    } finally {
                        is.close();
                    }
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage() != null ? t.getMessage() : t.toString());
                }
                final String fres = res;
                taskDone(err, "Replaced " + e.name + ": " + fres);
            }
        }).start();
    }

    // ---------------------------------------------------------------- export list

    private void exportList() {
        if (archive == null) {
            Toast.makeText(this, "Open an archive first.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE, "obb_file_list.txt");
        startActivityForResult(i, REQ_LIST);
    }

    private void doExportList(final Uri dest) {
        final ObbArchive a = archive;
        if (a == null) return;
        busy = true;
        new Thread(new Runnable() {
            public void run() {
                String err = null;
                try {
                    OutputStream os = getContentResolver().openOutputStream(dest, "wt");
                    try {
                        os.write(a.listing().getBytes("UTF-8"));
                    } finally {
                        os.close();
                    }
                } catch (Throwable t) {
                    err = String.valueOf(t.getMessage() != null ? t.getMessage() : t.toString());
                }
                taskDone(err, "File list saved");
            }
        }).start();
    }

    // ---------------------------------------------------------------- helpers

    private ObbArchive.Progress progressCb(final String label) {
        return new ObbArchive.Progress() {
            private long last;
            public void onProgress(long done, long total) {
                long now = System.currentTimeMillis();
                if (now - last < 150 && done < total) return;
                last = now;
                final int per = total > 0 ? (int) (done * 1000 / total) : 0;
                final String msg = label + " " + (per / 10) + "%";
                runOnUiThread(new Runnable() {
                    public void run() { setStatus(msg, per); }
                });
            }
        };
    }

    private void taskDone(final String err, final String okMsg) {
        runOnUiThread(new Runnable() {
            public void run() {
                busy = false;
                if (archive != null) { refreshInfo(archive.canWrite()); applyFilter(); }
                if (err != null) setStatus("Error: " + err, -1);
                else setStatus(okMsg, -1);
                Toast.makeText(MainActivity.this, err != null ? "Error: " + err : okMsg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setStatus(String s, int progress) {
        status.setText(s);
        if (progress >= 0) { bar.setVisibility(View.VISIBLE); bar.setProgress(progress); }
        else bar.setVisibility(View.GONE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_OPEN) {
            try {
                getContentResolver().takePersistableUriPermission(uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception e) { /* not persistable, fine */ }
            openArchive(uri);
        } else if (req == REQ_EXTRACT) doExtract(uri);
        else if (req == REQ_REPLACE) confirmReplace(uri);
        else if (req == REQ_LIST) doExportList(uri);
    }
}
